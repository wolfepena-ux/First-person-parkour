extends CharacterBody3D



@onready var camera: Camera3D = $Camera3D

const SPEED = 5.0
const JUMP_VELOCITY = 4.5


func _physics_process(delta: float) -> void:
	var forward_dir: Vector3 = -camera.global_transform.basis.z
	
	
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var input_dir := Input.get_vector("a", "d", "w", "s")
	if Input.is_action_pressed("w"):
		var direction := (transform.basis * Vector3(forward_dir.x, 0, forward_dir.y)).normalized()
		
		if direction:
			velocity.x = forward_dir.x * SPEED
			velocity.z = forward_dir.z * SPEED
		else:
			velocity.x = move_toward(forward_dir.x, 0, SPEED)
			velocity.z = move_toward(forward_dir.y, 0, SPEED)
	else: 
		velocity
	if Input.is_action_pressed("alt"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if Input.is_action_just_released("w"):
		velocity.x = 0
		velocity.z = 0
		velocity += get_gravity() * delta
	move_and_slide()
