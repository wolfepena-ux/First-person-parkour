extends Camera3D



@export var mouse_sensitivity: float = 0.002
@export var min_pitch: float = -89.0 # Lowest angle (looking down)
@export var max_pitch: float = 89.0  # Highest angle (looking up)



var rotation_x: float = 0.0
var rotation_y: float = 0.0

func _input(event):
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	# Check if the input event is a mouse motion event
	if event is InputEventMouseMotion:
		rotation_y -= event.relative.x * mouse_sensitivity
		rotation_x -= event.relative.y * mouse_sensitivity
		
		
		rotation_x = clamp(rotation_x, deg_to_rad(min_pitch), deg_to_rad(max_pitch))
		
		
		transform.basis = Basis() # Reset rotation matrix to prevent distortion
		rotate_y(rotation_y)
		rotate_object_local(Vector3.RIGHT, rotation_x)

		# event.relative gives a Vector2 (X for left/right, Y for up/down)
		var mouse_velocity = event.relative
		
		# Option A: Check general directional signs
		
